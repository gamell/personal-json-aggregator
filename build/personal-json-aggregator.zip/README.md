# personal-json-aggregator
Small function to aggregate and cache information from different sources for my personal website
